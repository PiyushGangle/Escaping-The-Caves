1. First install all the dependencies using Makefile by entering the following command:
	make install
This will install all the dependencies using pip3 by reading requirements.txt.
Then it will make the script "run.sh" executable.

After this, execute run.sh using the command:
	./run.sh
This will call two python programs:
	i] generatePairs.py => Will generate corresponding plaintext and ciphertext pairs in files "inputs.txt" and "outputs.txt".
    ii] analyzeDecrypt.py => It will find possible (E,A) values using the previously generated plaintext/ciphertexts pairs and will decrypt the password in two blocks and display the password.

2. To clean the local python cache, use the command:
	make clean