python3 ./generatePairs.py
python3 ./analyzeDecrypt.py