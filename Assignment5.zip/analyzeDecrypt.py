#!/usr/bin/env python
# coding: utf-8

# In[1]:


import time
import sys
from pyfinite import ffield as ff
hexchar = {0: 'f', 1: 'g', 2: 'h', 3: 'i', 4: 'j', 5: 'k', 6: 'l', 7: 'm', 8: 'n', 9: 'o', 10: 'p', 11: 'q', 12: 'r', 13: 's', 14: 't', 15: 'u'}
exps = [[-1]*128 for i in range(128)]
class AES_Operations:
    def createFField(self, deg):
        return ff.FField(deg)
    def exp(self, num, power):
        res = 0
        if exps[num][power] != -1: return exps[num][power]
        if power == 1: res = num
        elif power%2 == 0:
            sqrt_num = self.exp(num, power>>1)
            res = Field.Multiply(sqrt_num, sqrt_num)
        elif power == 0: res = 1
        else:
            sqrt_num = self.exp(num, power>>1)
            res = Field.Multiply(num, Field.Multiply(sqrt_num, sqrt_num))

        return res

    def mult(self,v,elem): #Scalar multiplication
        res = [0]*8
        res = [Field.Multiply(v[i],elem) for i in range(len(v))]
        return res
    def add(self, a,b): #vector addition
        res = [0]*8
        res = [a[i] ^ b[i] for i in range(len(a))]
        return res

    def linTrans(self, matrix,elist): #Linear transformation 
        res = [0]*8
        for ind in range(len(matrix)):
            elem = elist[ind]
            row = matrix[ind]
            res = self.add(self.mult(row,elem),res)
        return res

    def applyTransform(self, plain, linearMat, exponentMatrix):  # For performing EAEAE operations 
        plain = [ord(c) for c in plain]
        output = [[0 for j in range (8)] for i in range(8)]
        for index in range(len(plain)):
            output[0][index] = self.exp(plain[index], exponentMatrix[index])
        output[1] = self.linTrans(linearMat, output[0])

        for index in range(len(output[1])):
            ct = output[1][index]
            output[2][index] = self.exp(ct, exponentMatrix[index])
        output[3] = self.linTrans(linearMat, output[2])

        for index in range(len(output[3])):
            ct = output[3][index]
            output[4][index] = self.exp(ct, exponentMatrix[index])
        return output[4]
def tochar(b): #encoding ciphertext alphabets into binary
#         print(b//16)
        return hexchar[b//16]+hexchar[b%16] 

def toascii(cipher, plain=""): #convert cipher text block to ASCII
    for i in range(0,len(cipher),2):
#         print(cipher[i:i+2])
        plain += chr(16*(ord(cipher[i:i+2][0]) - ord('f')) + ord(cipher[i:i+2][1]) - ord('f'))
    return plain
oper = AES_Operations()
Field = oper.createFField(7) #For X^7 degree polynomial


# In[2]:


inputs = open("inputs.txt", 'r').readlines()
outputs = open("outputs.txt", 'r').readlines()
exponent_candidates = [[] for i in range(8)] #Possible exponent candidates
diagonal_candidates = [[[] for i in range(8)] for j in range(8)] #Possible diagonal values for A matrix

for index in range(len(inputs)):
    hex_inps = []
    hex_outs = []
    plain = inputs[index]
    cipher = outputs[index]
    for inp in plain.strip().split(" "): #Converting plaintext into hexadecimal
        hex_inps.append(toascii(inp)[index])
    for outp in cipher.strip().split(" "): ##Converting cipher text into hexadecimal
        hex_outs.append(toascii(outp)[index])       
    for i in range(1, 127):
        for j in range(1, 128):
            match = 1 #Checking validness of e_i and a_jj.
            for ind in range(len(hex_inps)): #Take inputs and outputs and iterate over all possible values.
                inp = hex_inps[ind]
                outp = hex_outs[ind]
                base = Field.Multiply(oper.exp(Field.Multiply(oper.exp(ord(inp), i), j), i), j)
                if ord(outp) != oper.exp(base, i):
                    match = 0
                    break
            if match == 0:
                pass
#                 print(exponent_candidates)
            else:
                exponent_candidates[index].append(i) # Storing possible candidates
                diagonal_candidates[index][index].append(j)
                
print(exponent_candidates)
print(diagonal_candidates)

for index in range(0,7):
    plain = inputs[index]
    cipher = outputs[index]
    hex_inps, hex_outs = [], []
    for inp in plain.strip().split(" "): # Convert to hex values
        hex_inps.append(toascii(inp)[index]) 
    for outp in cipher.strip().split(" "):
        hex_outs.append(toascii(outp)[index+1])
    for i in range(1, 128): # Explore all possible candidates for exponents and diagonal elements.
        for ec1,dc1 in zip(exponent_candidates[index+1], diagonal_candidates[index+1][index+1]):
            for ec2,dc2 in zip(exponent_candidates[index], diagonal_candidates[index][index]):
                match = 1
                for ind in range(len(hex_inps)): #Take inputs and outputs and iterate over all possible values.
                    inp = hex_inps[ind]
                    outp = hex_outs[ind]
                    base = (Field.Multiply(oper.exp(Field.Multiply(oper.exp(ord(inp), ec2), dc2), ec2), i) ^ Field.Multiply(oper.exp(Field.Multiply(oper.exp(ord(inp), ec2), i), ec1), dc1))
                    if ord(outp) != oper.exp(base, ec1):
                        match = 0
                        break
                if match == 1: # Store the correct values at corresponding indexes.
                    exponent_candidates[index+1] = [ec1]
                    exponent_candidates[index] = [ec2]
                    print(index,ec1,dc1,ec2,dc2,i)
                    diagonal_candidates[index][index] = [dc2]
                    diagonal_candidates[index][index+1] = [i]
                    diagonal_candidates[index+1][index+1] = [dc1]
print(exponent_candidates)
diagonal_candidates


# In[3]:


for index in range(6):
    exponents = [e[0] for e in exponent_candidates]
    linearTransformation = [[0 for i in range(8)] for j in range(8)] # Make other elements as 0.
    for i in range(8):
        for j in range(8):
            linearTransformation[i][j] = 0 if not len(diagonal_candidates[i][j]) else diagonal_candidates[i][j][0]
    for ind in range(len(inputs)):
        hex_inps = []
        hex_outs = []
        plain = inputs[ind]
        cipher = outputs[ind]
        if ind > (7-index - 2): continue
        inpString = [toascii(msg) for msg in plain.strip().split(" ")]
        outString = [toascii(msg) for msg in cipher.strip().split(" ")]
        for i in range(1, 128):
            offset = index + 2
            linearTransformation[ind][ind+offset] = i
            match = 1 # If EAEAE = Output, we consider them as valid candidates.
            for loc in range(len(inpString)):
                inps = inpString[loc]
                outs = outString[loc]
                if oper.applyTransform(inps,linearTransformation,exponents)[ind+offset] != ord(outs[ind+offset]):
                    match = 0
                    break
            if match == 1:
                print(ind,ind+offset,i) # for checking if values repeat for same index or not.
                diagonal_candidates[ind][ind+offset] = [i] # in our case, we get two possibilities for a[0][7]
                break # We break, as the first value worked for getting the password.
for i in range(8):
    for j in range(8):
#         print(len(diagonal_candidates[i][j]))
        linearTransformation[i][j] = 0 if not len(diagonal_candidates[i][j]) else diagonal_candidates[i][j][0]

print(exponents) #Final Candidates.
linearTransformation


# In[5]:


def decrypt(passwd):
    finalchars = "" # To store valid characters.
    passwd = toascii(passwd)
    for index in range(8):
        for num in range(128): # check all possible values and check if eaeae operated input matches with the password. 
            inp = finalchars + tochar(num)+(16-len(finalchars)-2)*'f'
            if oper.applyTransform(toascii(inp), linearTransformation, exponents)[index] == ord(passwd[index]):
                finalchars += tochar(num)
                #print(op)
                break
    return finalchars
password = 'ijlnglfufhlfmhfojlhilriklnlpmuik'
block1 = toascii(decrypt(password[:16]))
block2 = toascii(decrypt(password[16:]))
print("Password:", block1+block2)

