#!/usr/bin/env python
# coding: utf-8

# In[5]:


import time
import paramiko as pmk

to_cipher = {'0':'f', '1':'g', '2':'h', '3':'i', '4':'j', '5':'k', '6':'l', '7':'m', '8':'n', '9':'o', 'a':'p', 'b':'q', 'c':'r', 'd':'s', 'e':'t', 'f':'u'}
to_hex = {}
for key in to_cipher:
    to_hex[to_cipher[key]] = key
print(to_hex)
    
def toHex(word):
    return ''.join([to_hex[i] for i in word])

def toCipher(word):
    return ''.join([to_cipher[i] for i in word])
hostname = "172.27.26.188"
port = 22
username = "students"
password = "cs641a"

ssh = pmk.client.SSHClient()
ssh.load_system_host_keys()
ssh.set_missing_host_key_policy(pmk.AutoAddPolicy()) # Establish SSH connection
ssh.connect(hostname, port, username, password, allow_agent=False, look_for_keys=False)
chan = ssh.invoke_shell()


# In[ ]:


commands = ["INSYNC\n", "1234@Modern\n", "5\n", "go\n", "wave\n", "dive\n", "go\n", "read\n", "password\n"]
for command in commands:
    chan.send(command) # Entering correct commands found manually.
    time.sleep(0.2)
    chan.recv(5000)
    time.sleep(0.2)


# In[7]:


# Cipher = ijlnglfufhlfmhfojlhilriklnlpmuik
chan.send("c\n")
time.sleep(0.2)
chan.recv(5000)


# In[9]:


inputString = []
for a in range(1,128):
    byte = hex(a)[2:]
    if len(byte)==1: byte='0'+byte  # Padding to make it one byte(of two chars).
    for b in range(1,9):
        inp = toCipher(byte)
        word = 'ff'*(b-1)+inp+'ff'*(9-b-1)
        inputString.append(word)
inp = ['f'*16]*8
for i in range(8):
    for j in range(127): # Construct input string
        inp[i]+=' '+inputString[8*j+i][:16]

inpfile = open("inputs.txt","w")
for i in inp:
    inpfile.write(i)
    inpfile.write("\n")
inpfile.close()

inpfile = open('inputs.txt', 'r')
lines = inpfile.readlines()
out = []
for line in lines:
    cip=''
    for inp in line.split():
        chan.send(inp+"\n")
        time.sleep(0.1)
        x = chan.recv(5000)
        x = x[-43:-27] # Fetch corresponding ciphertext.
        print(inp,x)
        cip += ' ' + x.decode("UTF-8")
        chan.send("c\n")
        time.sleep(0.1)
        chan.recv(5000)
    out.append(cip[1:])

outfile = open("outputs.txt","w")
for i in out:
    outfile.write(i)
    outfile.write("\n")
outfile.close()

