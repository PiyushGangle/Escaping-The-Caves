1. First install all the dependencies using Makefile by entering the following command:
	make install
This will install all the dependencies like sagemath.
Then it will make the script "run.sh" executable.

After this, execute run.sh using the command:
	./run.sh
This will call the sage script "breakRSA.sage":
	i] This will run the coppersmith algorithm on our ciphertext, N and exponent e = 5.
2. To clean the local python cache, use the command:
	make clean
