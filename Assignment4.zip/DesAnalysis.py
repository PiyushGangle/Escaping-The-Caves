#!/usr/bin/env python
# coding: utf-8

# In[2]:


import operator


# In[3]:


# Hexadecimal to binary conversion 
def hex2bin(s): 
    mp = {'0' : "0000",  
          '1' : "0001", 
          '2' : "0010",  
          '3' : "0011", 
          '4' : "0100", 
          '5' : "0101",  
          '6' : "0110", 
          '7' : "0111",  
          '8' : "1000", 
          '9' : "1001",  
          'A' : "1010", 
          'B' : "1011",  
          'C' : "1100", 
          'D' : "1101",  
          'E' : "1110", 
          'F' : "1111" } 
    bin = ""
    n1 = len(s)
    for i in range(0,n1): 
        bin+=mp[s[i]] 
    return bin
      
# Binary to hexadecimal conversion 
def bin2hex(s): 
    mp = {"0000" : '0',  
          "0001" : '1', 
          "0010" : '2',  
          "0011" : '3', 
          "0100" : '4', 
          "0101" : '5',  
          "0110" : '6', 
          "0111" : '7',  
          "1000" : '8', 
          "1001" : '9',  
          "1010" : 'A', 
          "1011" : 'B',  
          "1100" : 'C', 
          "1101" : 'D',  
          "1110" : 'E', 
          "1111" : 'F' } 
    hex = "" 
    n1= len(s)
    for i in range(0,n1,4): 
        ch = "" 
        ch = ch + s[i] 
        ch = ch + s[i + 1]  
        ch = ch + s[i + 2]  
        ch = ch + s[i + 3]  
        hex+=mp[ch] 
          
    return hex
  
# Binary to decimal conversion 
def bin2dec(binary):  
        
    binary1 = binary  
    decimal, i, n = 0, 0, 0
    while(binary != 0):  
        dec = binary % 10
        decimal = decimal + dec * pow(2, i)  
        binary = binary//10
        i += 1
    return decimal 
  
# Decimal to binary conversion 
def dec2bin(num):  
    res = bin(num).replace("0b", "") 
    if(len(res)%4 != 0): 
        div = len(res) / 4
        div = int(div) 
        counter =(4 * (div + 1)) - len(res)  
        for i in range(0, counter): 
            res = '0' + res 
    return res 
  
# Permute function to rearrange the bits 
def permute(k, arr, n): 
    permutation = "" 
    for i in range(0, n): 
        permutation = permutation + k[arr[i] - 1] 
    return permutation 
  
# shifting the bits towards left by nth shifts 
def shift_left(k, nth_shifts): 
    s = "" 
    for i in range(nth_shifts):
        n2 = len(k)
        for j in range(1,n2): 
            s+= k[j] 
        s+= k[0] 
        k = s 
        s = ""  
    return k     
  
# calculating xor of two strings of binary number a and b 
def xor(a, b): 
    ans = ""
    n2 = len(a)
    for i in range(0,n2): 
        if a[i] == b[i]: 
            ans+="0"
        else: 
            ans+="1"
    return ans 

#
#Permutation matrix 1 for key schedule
pc1=[                  
  57, 49, 41, 33, 25, 17, 9,
  1, 58, 50, 42, 34, 26, 18,
  10,  2, 59, 51, 43, 35, 27,
  19, 11,  3, 60, 52, 44, 36,
  63, 55, 47, 39, 31, 23, 15, 
  7, 62, 54, 46, 38, 30, 22, 
  14,  6, 61, 53, 45, 37, 29, 
  21, 13,  5, 28, 20, 12,  4
]
#Permutation matrix 2 for key schedule
pc2 = [                 
  14, 17, 11, 24,  1, 5, 
  3, 28 ,15,  6, 21, 10, 
  23, 19, 12,  4, 26, 8, 
  16,  7, 27, 20, 13, 2, 
  41, 52, 31, 37, 47, 55, 
  30, 40, 51, 45, 33, 48, 
  44, 49, 39, 56, 34, 53, 
  46, 42, 50, 36, 29, 32
]
#Inverse of P
INV_P = [9, 17, 23, 31,
	      13, 28,  2, 18,
	      24, 16, 30,  6,
	      26, 20, 10,  1,
	       8, 14, 25,  3,
	       4, 29, 11, 19,
	      32, 12, 22,  7,
	       5, 27, 15, 21
         ]
# Table of Position of 64 bits at initail level: Initial Permutation Table 
initial_perm = [58, 50, 42, 34, 26, 18, 10, 2,  
                60, 52, 44, 36, 28, 20, 12, 4,  
                62, 54, 46, 38, 30, 22, 14, 6,  
                64, 56, 48, 40, 32, 24, 16, 8,  
                57, 49, 41, 33, 25, 17, 9, 1,  
                59, 51, 43, 35, 27, 19, 11, 3,  
                61, 53, 45, 37, 29, 21, 13, 5,  
                63, 55, 47, 39, 31, 23, 15, 7]  
  
# Expansion E-box Table 
exp_d = [32, 1 , 2 , 3 , 4 , 5 , 4 , 5,  
         6 , 7 , 8 , 9 , 8 , 9 , 10, 11,  
         12, 13, 12, 13, 14, 15, 16, 17,  
         16, 17, 18, 19, 20, 21, 20, 21,  
         22, 23, 24, 25, 24, 25, 26, 27,  
         28, 29, 28, 29, 30, 31, 32, 1 ] 
  
# Straight Permutaion Table 
per = [ 16,  7, 20, 21, 
        29, 12, 28, 17,  
         1, 15, 23, 26,  
         5, 18, 31, 10,  
         2,  8, 24, 14,  
        32, 27,  3,  9,  
        19, 13, 30,  6,  
        22, 11,  4, 25 ] 
  
# S-box Table 
sbox = [[[14, 4, 13, 1, 2, 15, 11, 8, 3 , 10, 6, 12, 5, 9, 0, 7],
    [0, 15, 7, 4, 14, 2, 13, 1, 10, 6, 12, 11, 9, 5, 3, 8],
    [4, 1 , 14, 8, 13, 6, 2, 11, 15, 12, 9, 7,3, 10, 5, 0],
    [15, 12, 8,2,4, 9, 1,7 , 5, 11, 3, 14, 10, 0, 6, 13]],

    [[15, 1, 8, 14, 6, 11, 3, 4, 9, 7, 2, 13, 12, 0,5, 10],
    [3, 13, 4, 7, 15, 2, 8, 14, 12, 0, 1, 10, 6, 9, 11, 5],
    [0, 14, 7, 11, 10, 4, 13, 1, 5, 8,12, 6, 9, 3, 2, 15],
    [13, 8, 10, 1, 3, 15, 4, 2,11,6, 7, 12, 0,5, 14, 9]],

    [[10, 0, 9,14,6,3,15,5, 1, 13, 12, 7, 11, 4,2,8],
    [13, 7, 0, 9, 3, 4, 6, 10, 2, 8, 5, 14, 12, 11, 15, 1],
    [13, 6, 4, 9, 8, 15, 3, 0, 11, 1, 2, 12,5, 10, 14, 7],
    [1, 10, 13, 0, 6, 9, 8, 7, 4, 15, 14, 3, 11, 5, 2, 12]],

    [[7, 13, 14, 3, 0, 6, 9, 10, 1, 2, 8, 5, 11, 12, 4, 15],
    [13, 8, 11, 5, 6, 15, 0, 3, 4, 7, 2, 12, 1, 10, 14, 9],
    [10, 6, 9, 0, 12, 11, 7, 13, 15, 1 , 3, 14, 5, 2, 8, 4],
    [3, 15, 0, 6, 10, 1, 13, 8, 9, 4, 5, 11, 12, 7, 2, 14]],

    [[2, 12, 4, 1, 7, 10, 11, 6, 8, 5, 3, 15, 13, 0, 14, 9],
    [14, 11,2, 12, 4, 7, 13, 1, 5, 0, 15, 10, 3, 9, 8, 6],
    [4, 2, 1, 11, 10, 13, 7, 8, 15, 9, 12, 5, 6, 3, 0, 14],
    [11, 8, 12, 7, 1, 14, 2, 13, 6, 15, 0, 9, 10, 4, 5, 3]],

    [[12, 1, 10, 15, 9, 2, 6,8, 0, 13, 3, 4, 14, 7, 5, 11],
    [10, 15, 4, 2, 7, 12, 9, 5, 6, 1, 13, 14, 0, 11, 3, 8],
    [9, 14, 15, 5, 2,8, 12, 3, 7, 0, 4, 10, 1, 13, 11, 6],
    [4, 3, 2, 12, 9, 5, 15, 10, 11, 14, 1, 7, 6, 0, 8, 13]],

    [[4, 11, 2, 14, 15, 0, 8, 13, 3, 12, 9, 7, 5, 10, 6, 1],
    [13, 0, 11, 7, 4, 9, 1, 10, 14, 3, 5, 12, 2, 15, 8, 6],
    [1, 4, 11, 13, 12, 3, 7, 14, 10, 15, 6, 8, 0, 5, 9, 2],
    [6, 11, 13, 8, 1, 4, 10, 7, 9, 5, 0, 15, 14, 2, 3, 12]],

    [[13, 2, 8, 4, 6, 15, 11, 1, 10, 9, 3, 14, 5, 0, 12,7],
    [1, 15, 13, 8, 10, 3, 7, 4, 12, 5, 6, 11, 0, 14, 9, 2],
    [7, 11, 4, 1, 9, 12, 14, 2, 0, 6, 10, 13, 15, 3, 5, 8],
    [2, 1, 14, 7, 4, 10, 8, 13, 15, 12, 9, 0, 3, 5, 6, 11]]] 
    

final_perm = [ 40, 8, 48, 16, 56, 24, 64, 32,  
               39, 7, 47, 15, 55, 23, 63, 31,  
               38, 6, 46, 14, 54, 22, 62, 30,  
               37, 5, 45, 13, 53, 21, 61, 29,  
               36, 4, 44, 12, 52, 20, 60, 28,  
               35, 3, 43, 11, 51, 19, 59, 27,  
               34, 2, 42, 10, 50, 18, 58, 26,  
               33, 1, 41, 9, 49, 17, 57, 25 ] 

f2u_mapping={'d' : '0000',
           'e' : '0001',
           'f' : '0010',
           'g' : '0011',
           'h' : '0100',
           'i' : '0101',
           'j' : '0110',
           'k' : '0111',
           'l' : '1000',
           'm' : '1001',
           'n' : '1010',
           'o' : '1011',
           'p' : '1100',
           'q' : '1101',
           'r' : '1110',
           's' : '1111'}
     

# --parity bit drop table 
keyp = [57, 49, 41, 33, 25, 17, 9,  
        1, 58, 50, 42, 34, 26, 18,  
        10, 2, 59, 51, 43, 35, 27,  
        19, 11, 3, 60, 52, 44, 36,  
        63, 55, 47, 39, 31, 23, 15,  
        7, 62, 54, 46, 38, 30, 22,  
        14, 6, 61, 53, 45, 37, 29,  
        21, 13, 5, 28, 20, 12, 4 ] 


RFP = [57, 49, 41, 33, 25, 17, 9,  1,
       59, 51, 43, 35, 27, 19, 11, 3,
       61, 53, 45, 37, 29, 21, 13, 5,
       63, 55, 47, 39, 31, 23, 15, 7,
       58, 50, 42, 34, 26, 18, 10, 2,
       60, 52, 44, 36, 28, 20, 12, 4,
       62, 54, 46, 38, 30, 22, 14, 6,
       64, 56, 48, 40, 32, 24, 16, 8]

#shift table 
shift_table = [1, 1, 2, 2,  
                2, 2, 2, 2,  
                1, 2, 2, 2,  
                2, 2, 2, 1 ] 
  
# Key- Compression Table : Compression of key from 56 bits to 48 bits 
key_comp = [14, 17, 11, 24, 1, 5,  
            3, 28, 15, 6, 21, 10,  
            23, 19, 12, 4, 26, 8,  
            16, 7, 27, 20, 13, 2,  
            41, 52, 31, 37, 47, 55,  
            30, 40, 51, 45, 33, 48,  
            44, 49, 39, 56, 34, 53,  
            46, 42, 50, 36, 29, 32 ] 
  


# ## Computing XORs at IN and OUT of S-boxes

# In[4]:


import numpy as np


# In[5]:


#create hex mapping of 16 letters present in ciphertext. f=0, g=1 ,so on...
mapping = {
           'd' : [0,0,0,0],
           'e' : [0,0,0,1],
           'f' : [0,0,1,0],
           'g' : [0,0,1,1],
           'h' : [0,1,0,0],
           'i' : [0,1,0,1],
           'j' : [0,1,1,0],
           'k' : [0,1,1,1],
           'l' : [1,0,0,0],
           'm' : [1,0,0,1],
           'n' : [1,0,1,0],
           'o' : [1,0,1,1],
           'p' : [1,1,0,0],
           'q' : [1,1,0,1],
           'r' : [1,1,1,0],
           's' : [1,1,1,1]
           }


# In[6]:


#list of all ciphertexts in hex as per mapping
cipher=[]
#read in the output file after encrypting plaintexts from input.txt
lines = open("ciphertexts1.txt").read().split("\n")

n=len(lines)
for i in range(0,n):
  #checking if a ciphertext is not of 16 letters
    if(len(lines[i]) == 16):
        #temp list
        st=[]
        print(lines[i])
        for j in range(16):
            st+=mapping[lines[i][j]]
        cipher+=[st]    
#print(cipher[0])


# In[7]:


#applying inverse final permutation on each 64 (=16*4) bit ciphertext
n=len(cipher)
ifp_res = []
for i in range(0,n):
    ifp_res2 = []
    for j in range(64):
        ifp_res2+=[cipher[i][RFP[j]-1]]
    ifp_res+=[ifp_res2]
#print(ifp_res2[0:10])


# In[8]:


#XOR of inverse permuted ciphertext's result
ifp_XOR=[]
for i in range(0,n//2):
    ifp_XOR+= [list(np.bitwise_xor(ifp_res[2*i+1],ifp_res[2*i]))]


# In[9]:


#Expansion of R5
exp_out=[]
for i in range(0,n):
    exp_out2=[]
    for j in range(0,48):
        exp_out2+=[ifp_res[i][exp_d[j]-1]]
    exp_out+=[exp_out2]
#print(exp_out[0])


# In[10]:


#XOR of expanded outputs to find inputs to s-boxes
sbox_in=[]
for i in range(0,n//2):
    sbox_in+= [list(np.bitwise_xor(exp_out[2*i+1],exp_out[2*i]))]
#print(sbox_in[0])            


# In[11]:


#XOR of L5 and R6 from inverse permuted ciphertexts
L5 = [0,0,0,0,0,1]+[0]*26
xor_out=[]
for i in range(0,len(ifp_XOR)):
    xor_out+=[list(np.bitwise_xor(ifp_XOR[i][32:64],L5))]


# In[12]:


#XOR of outputs after s-boxes
sbox_out = []
for i in range(0,len(xor_out)):
    sbox_out2=[]
    for j in range(0,32):
        sbox_out2+=[xor_out[i][INV_P[j]-1]]
    sbox_out+=[sbox_out2]


# In[13]:


#storing expanded outputs
with open("exp_out1.txt","w") as f:
    n1 = len(exp_out)
    for i in range(0,n1):
        if(i%2!=1):
            temp=""
            for j in exp_out[i]:
                temp+=str(j)
            f.write(temp+"\n")
f.close()


# In[14]:


#storing inputs to s-boxes
with open("sbox_in1.txt","w") as f:
    for i in sbox_in:
        temp=""
        for j in i:
            temp+=str(j)
        f.write(temp+"\n")
f.close()


# In[15]:


#storing outputs of s-boxes
with open("sbox_out1.txt","w") as f:
    for i in sbox_out:
        temp=""
        for j in i:
            temp+=str(j)
        f.write(temp+"\n")
f.close()


# ## Finding the Keys for S-Boxes of Round 6 for characteristic 1

# In[16]:


Keys = np.zeros((8,64))


# In[17]:


sbox_in=[]
sbox_out=[]
exp_out=[]
sbox_in = open("sbox_in1.txt").read().split("\n")
sbox_out = open("sbox_out1.txt").read().split("\n")
exp_out = open("exp_out1.txt").read().split("\n")


# In[18]:


for i in range(len(sbox_in)):
    if sbox_in[i]=="":
        continue     
    for j in range(0,8):
        inx = int(sbox_in[i][j*6:j*6+6], 2)
        outx = int(sbox_out[i][j*4:j*4+4], 2)
        inp_orig = int(exp_out[i][j*6:j*6+6], 2)
        for k in range(0,64):
            a = bin(k)[2:].zfill(6)
            b = bin(k^inx)[2:].zfill(6)  
            if outx == sbox[j][int(a[0])*2 + int(a[5])][int(a[4]) + 2 *int(a[3]) + int(a[2]) * 4 + int(a[1])*8]^sbox[j][int(b[0])*2 + int(b[5])][int(b[4]) + 2 *int(b[3]) + int(b[2]) * 4 + int(b[1])*8]:
                key_cand = k^inp_orig
                Keys[j][key_cand] = Keys[j][key_cand] + 1


# In[19]:


print(Keys)


# In[20]:


maxval = []
mean = []
keyval = []
for i in Keys:
    index, value = max(enumerate(i), key=operator.itemgetter(1))
    maxval+=[int(value)]
    keyval+=[index]
    mean+=[int(round(np.mean(i)))]
print("S-box"+ "\t" +"Max" + "\t" + "Mean" + "\t" + "Key")
for i in range(0,8):
    print("S"+ str(i+1) +"\t"+ str(maxval[i]) + "\t" + str(mean[i]) + "\t" + str(keyval[i]))


# ## Computing XORs at IN and OUT of S-boxes for characteristic 2

# In[21]:


#list of all ciphertexts in hex as per mapping
cipher=[]
#read in the output file after encrypting plaintexts from input.txt
lines = open("ciphertexts2.txt").read().split("\n")

n=len(lines)
for i in range(0,n):
  #checking if a ciphertext is not of 16 letters
    if(len(lines[i]) == 16):
        #temp list
        st=[]
        for j in range(16):
            st+=mapping[lines[i][j]]
        cipher+=[st]    


# In[22]:


#applying inverse final permutation on each 64 (=16*4) bit ciphertext
n=len(cipher)
ifp_res = []
for i in range(0,n):
    ifp_res2 = []
    for j in range(64):
        ifp_res2+=[cipher[i][RFP[j]-1]]
    ifp_res+=[ifp_res2]


# In[23]:


#XOR of inverse permuted ciphertext's result
ifp_XOR=[]
for i in range(0,n//2):
    ifp_XOR+= [list(np.bitwise_xor(ifp_res[2*i+1],ifp_res[2*i]))]


# In[24]:


#Expansion of R5
exp_out=[]
for i in range(0,n):
    exp_out2=[]
    for j in range(0,48):
        exp_out2+=[ifp_res[i][exp_d[j]-1]]
    exp_out+=[exp_out2]
#print(exp_out[0])


# In[25]:


#XOR of expanded outputs to find inputs to s-boxes
sbox_in=[]
for i in range(0,n//2):
    sbox_in+= [list(np.bitwise_xor(exp_out[2*i+1],exp_out[2*i]))]
#print(sbox_in[0])            


# In[26]:


#XOR of L5 and R6 from inverse permuted ciphertexts
L5 = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0]
# print(len(L5))
xor_out=[]
for i in range(0,len(ifp_XOR)):
    xor_out+=[list(np.bitwise_xor(ifp_XOR[i][32:64],L5))]


# In[27]:


#XOR of outputs after s-boxes
sbox_out = []
for i in range(0,len(xor_out)):
    sbox_out2=[]
    for j in range(0,32):
        sbox_out2+=[xor_out[i][INV_P[j]-1]]
    sbox_out+=[sbox_out2]


# In[28]:


#storing expanded outputs
with open("exp_out2.txt","w") as f:
    n1 = len(exp_out)
    for i in range(0,n1):
        if(i%2!=1):
            temp=""
            for j in exp_out[i]:
                temp+=str(j)
            f.write(temp+"\n")
f.close()


# In[29]:


#storing inputs to s-boxes
with open("sbox_in2.txt","w") as f:
    for i in sbox_in:
        temp=""
        for j in i:
            temp+=str(j)
        f.write(temp+"\n")
f.close()


# In[30]:


#storing outputs of s-boxes
with open("sbox_out2.txt","w") as f:
    for i in sbox_out:
        temp=""
        for j in i:
            temp+=str(j)
        f.write(temp+"\n")
f.close()


# ## Finding the Keys for S-Boxes of Round 6 for characteristic 2

# In[31]:


Keys = np.zeros((8,64))


# In[32]:


sbox_in=[]
sbox_out=[]
exp_out=[]
sbox_in = open("sbox_in2.txt").read().split("\n")
sbox_out = open("sbox_out2.txt").read().split("\n")
exp_out = open("exp_out2.txt").read().split("\n")


# In[33]:


for i in range(len(sbox_in)):
    if sbox_in[i]=="":
        continue     
    for j in range(0,8):
        inx = int(sbox_in[i][j*6:j*6+6], 2)
        outx = int(sbox_out[i][j*4:j*4+4], 2)
        inp_orig = int(exp_out[i][j*6:j*6+6], 2)
        for k in range(0,64):
            a = bin(k)[2:].zfill(6)
            b = bin(k^inx)[2:].zfill(6)  
            if outx == sbox[j][int(a[0])*2 + int(a[5])][int(a[4]) + 2 *int(a[3]) + int(a[2]) * 4 + int(a[1])*8]^sbox[j][int(b[0])*2 + int(b[5])][int(b[4]) + 2 *int(b[3]) + int(b[2]) * 4 + int(b[1])*8]:
                key_cand = k^inp_orig
                Keys[j][key_cand] = Keys[j][key_cand] + 1


# In[34]:


print(Keys)


# In[35]:


maxval = []
mean = []
keyval = []
for i in Keys:
    index, value = max(enumerate(i), key=operator.itemgetter(1))
    maxval+=[int(value)]
    keyval+=[index]
    mean+=[int(round(np.mean(i)))]
print("S-box"+ "\t" +"Max" + "\t" + "Mean" + "\t" + "Key")
for i in range(0,8):
    print("S"+ str(i+1) +"\t"+ str(maxval[i]) + "\t" + str(mean[i]) + "\t" + str(keyval[i]))


# ## Finding the Master Key

# In[36]:


s_box_key="101101110011XXXXXX000111111110011000010011100100"
Master_key=['X']*56

for i in range(len(s_box_key)):
    Master_key[pc2[i]-1]=s_box_key[i]             
shifts=[1, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1]     
for i in range(0,6):
    for j in range(shifts[i]):
        temp2=Master_key[27]
        temp1=Master_key[55]
        for k in range(27,0,-1):
            Master_key[k]=Master_key[k-1]
            Master_key[k+28]=Master_key[k+27]
        Master_key[0]=temp2
        Master_key[28]=temp1
print("".join(Master_key))


# ## Generating all possible keys using the obtained Master Key

# In[37]:


#Master Key is X 11 XX 1 XX 01011 X 100 XX 11 X 11000 X 1010111 X 00001001 X 11 X 0110 X 001
possible=[]
for i in range(0,2**14):
    possible.append(str(i//8192%2)+'11'+str(i//4096%2)+str(i//2048%2)+'1' + str(i//1024%2)+ str(i//512%2)+'01011'+str(i//256%2)+'100'+str(i//128%2) + str(i//64%2)+'11'+str(i//32%2)+'11000' + str(i//16%2) + "1010111" + str(i//8%2)+'00001001' + str(i//4%2) + "11" + str(i//2%2) + '0110' + str(i%2) + "001" + '\n')


# ## Brute Force to find the Actual Key

# In[38]:


def generate_round_keys(k, ro):
    l=k[0:28]     
    r=k[28:56]  
    #binary round keys
    kb = []
    #hex keys
    kh  = []
    for i in range(0,ro): 
        #shift bits by n using shift table 
        l = shift_left(l, shift_table[i]) 
        r = shift_left(r, shift_table[i]) 
        #merge
        mer=l+r 
        #compress key from 56 to 48 bits using key compression table
        kb+=[permute(mer, key_comp, 48)] 
        kh+=[bin2hex(permute(mer, key_comp, 48))]
    return kb


# In[39]:


def encrypt(pt, kb,ro):  
    # Initial Permutation 
    pt = permute(pt, initial_perm, 64)
      
    #break into left and right half
    l = pt[0:32] 
    r= pt[32:64] 
    for i in range(0,ro): 
        #expand 32 bits to 48 
        r_exp = permute(r, exp_d, 48) 
          
        #XOR ith roundkey and r_exp  
        r_xor = xor(r_exp,kb[i]) 
        #substituting the value from s-box table by calculating row and column  
        sbox_st = "" 
        for j in range(0,8): 
            row = bin2dec(int(r_xor[j*6] + r_xor[j*6+5])) 
            col = bin2dec(int(r_xor[j*6+1] + r_xor[j*6+2] + r_xor[j*6+3] + r_xor[j*6+4])) 
            value = sbox[j][row][col] 
            sbox_st = sbox_st+dec2bin(value) 
              
        #rearrange bits   
        sbox_st = permute(sbox_st, per, 32) 
          
        #XOR left half and sbox_st 
        res= xor(l, sbox_st) 
        l = res        
        if(i!=5): 
            temp = l
            l = r
            r = temp
    #merge
    mer=l+r 
      
    #rearrange bits to get ciphertext 
    ciphertext = permute(mer, final_perm, 64) 
    return ciphertext


# In[40]:


bin_pt = ""
for i in "dddddddddddddddd":
    bin_pt += f2u_mapping[i]
bin_ct = ""
for i in "ofjopjgiiodmmrkj":
    bin_ct += f2u_mapping[i]
    
for k in possible:
    kb = generate_round_keys(k,6)
    if(encrypt(bin_pt,kb,6) == bin_ct):
        # required = k
        print("Key is: " + k)
        break


# ## Finding the keys for All Rounds using the Actual Key

# In[41]:


key='01101110010111100111101100001010111100001001111101100001'
l = key[0:28]     
r = key[28:56]  

#binary round keys
kb = []
for i in range(0,6): 
    #shift bits by n using shift table 
    l = shift_left(l, shift_table[i]) 
    r = shift_left(r, shift_table[i]) 

    #merge
    mer=l+r 
    #using key compression table, compress the key from 56 to 48 bits
    kb.append(permute(mer, key_comp, 48))
    print("Round "  + str(i+1) +"=>"+kb[i])

