#!/usr/bin/env python
# coding: utf-8

# ## Generating plaintexts

# In[5]:


import numpy as np
import random


# In[6]:


dictionary = {
 '0000': 'd',
 '0001': 'e',
 '0010': 'f',
 '0011': 'g',
 '0100': 'h',
 '0101': 'i',
 '0110': 'j',
 '0111': 'k',
 '1000': 'l',
 '1001': 'm',
 '1010': 'n',
 '1011': 'o',
 '1100': 'p',
 '1101': 'q',
 '1110': 'r',
 '1111': 's'
}
rev_dict=mapping = {
           'd' : '0000',
           'e' : '0001',
           'f' : '0010',
           'g' : '0011',
           'h' : '0100',
           'i' : '0101',
           'j' : '0110',
           'k' : '0111',
           'l' : '1000',
           'm' : '1001',
           'n' : '1010',
           'o' : '1011',
           'p' : '1100',
           'q' : '1101',
           'r' : '1110',
           's' : '1111'
           }
print(rev_dict.keys())


# In[8]:


XOR_value = list((bin(0x0000801000004000))[2:].zfill(64))
binary_plaintexts = []
XOR_value = [int(x) for x in XOR_value]
for i in range(1000):
    tmp=[]
    for j in range(16):
        x= random.choice(['d', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's'])
        tmp.append(x)
    inp1=''
    for y in tmp:
        inp1+=rev_dict[y]
    inp1 = [int(inp1[j]) for j in range(len(inp1))]
    binary_plaintexts.append(inp1)
    binary_plaintexts.append(list(np.bitwise_xor(inp1,XOR_value)))


# In[9]:


def listToString(s):  
    s1 = [str(x) for x in s] 
    str1 = "" 
    return (str1.join(s1))
inputs = []
for i in range(len(binary_plaintexts)):
    input=""
    for j in range(0,64,4):
        temp1 = binary_plaintexts[i][j:j+4]
        temp2 = listToString(temp1)
        input+=dictionary[temp2]
        #print(input)
    inputs+=[input]


# In[10]:


newfile = open("plaintexts1.txt","w")
for plaintext in inputs:
    newfile.write(plaintext+"\n")
newfile.close()


# In[11]:


# XOR value between pairs of plaintexts is 0000 0000 0000 0000 0000 1000 0000 0001 0000 0000 0001 0000 0000 0000 0000 0000
XOR_value = list((bin(0x0000080100100000))[2:].zfill(64))
XOR_value = [int(x) for x in XOR_value]
binary_plaintexts = []
for i in range(1000):
    tmp=[]
    for j in range(16):
        x= random.choice(['d', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's'])
        tmp.append(x)
    inp1=''
    for y in tmp:
        inp1+=rev_dict[y]
    inp1 = [int(inp1[j]) for j in range(len(inp1))]
    binary_plaintexts.append(inp1)
    binary_plaintexts.append(list(np.bitwise_xor(inp1,XOR_value)))


# In[12]:


def listToString(s):  
    s1 = [str(x) for x in s] 
    str1 = "" 
    # return string   
    return (str1.join(s1))
inputs = []
for i in range(len(binary_plaintexts)):
    input=""
    for j in range(0,64,4):
        temp1 = binary_plaintexts[i][j:j+4]
        temp2 = listToString(temp1)
        input+=dictionary[temp2]
        #print(input)
    inputs+=[input]


# In[13]:


newfile = open("plaintexts2.txt","w")
for plaintext in inputs:
    newfile.write(plaintext+"\n")
newfile.close()

