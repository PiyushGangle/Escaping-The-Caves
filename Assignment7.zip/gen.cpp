#include <stdio.h>
#include <iostream>
using namespace std;
#define spsp " "
int pow(long long x, unsigned int y, int p=127)
{
	int res = 1;	 // Initialize result

	x = x % p; // Update x if it is more than or
				// equal to p

	if (x == 0) return 0; // In case x is divisible by p;

	while (y > 0)
	{
		// If y is odd, multiply x with result
		if (y & 1)
			res = (res*x) % p;

		// y must be even now
		y = y>>1; // y = y/2
		x = (x*x) % p;
	}
	return res;
}

int main(){
cout<<pow(2,8)<<" "<<pow(2,63)<<endl;
int rhs[] = {22,99,12,109,96,77,112,24,120,2,70,17,88,13,116,79,84,101,113,48,108,65,45,2,60,84,32,10,60,62,42,87};
int power, satisfy=1, sat=1,sump=0, store = 0;
int a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v;
long long int tot = (long long int)(22*22*22*22*22*22)*(long long int)(22*22*22*22);
cout<<"Starting\n";

for(a=102; a<=117;a++ )
 for(b=a; b<=117;b++ )
  for(c=b; c<=117;c++ )
   for(d=c; d<=117;d++ ){ cout<<"a= "<<a<<" b="<<b<<" c="<<c<<" d="<<d<<endl;
    for(e=d; e<=117;e++ )
     for(f=e; f<=117;f++ )
      for(g=f; g<=117;g++ )
       for(h=g; h<=117;h++ )
        for(i=h; i<=117;i++ )
         for(j=i; j<=117;j++ )
          for(k=j; k<=117;k++ )
           for(l=k; l<=117;l++ )
            for(m=l; m<=117;m++ )
             for(n=m; n<=117;n++ )
              for(o=n; o<=117;o++ )
               for(p=o; p<=117;p++ )
                for(q=p; q<=117;q++ )
                 for(r=q; r<=117;r++ )
                  for(s=r; s<=117;s++ )
                   for(t=s; t<=117;t++ )
                    for(u=t; u<=117;u++ )
                     for(v=u; v<=117;v++ ){
			satisfy = 1;sat = 0;
			for(power = 1; power <=15; power++){
			store = pow(a,power,127)+pow(b,power,127)+pow(c,power,127)+pow(d,power,127)+pow(e,power,127)+pow(f,power,127)+pow(g,power,127)+pow(h,power,127)+pow(i,power,127)+pow(j,power,127)+pow(k,power,127)+pow(l,power,127)+pow(m,power,127)+pow(n,power,127)+pow(o,power,127)+pow(p,power,127)+pow(q,power,127)+pow(r,power,127)+pow(s,power,127)+pow(t,power,127)+pow(u,power,127)+pow(v,power,127);
			sump = store%127;
			sat = ( sump == rhs[power]);
			if(!sat) break;
			}
			if(sat)
			cout<<"**Sat "<<a<<" "<<b<<" "<<c<<" "<<d<<" "<<e<<" "<<f<<" "<<g<<" "<<h<<" "<<i<<" "<<j<<" "<<k<<" "<<l<<" "<<m<<" "<<n<<" "<<o<<" "<<p<<" "<<q<<" "<<r<<" "<<s<<" "<<t<<" "<<u<<" "<<v<<endl;
			}
			
			}
cout<<"End Bye";
return 0;
}
