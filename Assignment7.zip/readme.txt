1. First install all the dependencies using Makefile by entering the following command:
	make install
This will install all the dependencies like g++.
Then it will make the script "run.sh" executable.

After this, execute run.sh using the command:
	./run.sh
This will call g++ with gen.cpp as argument and will run 'a.out'. This will run and execute the hash comparisons for all the 22 equations.
Finally we can convert the ascii values produced by our program to text using python or any online platform.

2. To clean the local python cache, use the command:
	make clean

Note: The code for modulus exponentiation function in our c++ code is taken from geeksforgeeks.com
