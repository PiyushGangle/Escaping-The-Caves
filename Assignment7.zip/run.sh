g++ ./gen.cpp
./a.out
